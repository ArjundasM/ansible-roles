import boto
import json
import re as re
from collections import OrderedDict
from pyspark.sql import Row
from pyspark.sql import functions as F
from pyspark.sql.functions import col
from pyspark.sql.functions import initcap
from pyspark.sql.functions import log
from pyspark.sql.functions import lower
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.functions import regexp_replace
from pyspark.sql.functions import split
from pyspark.sql.functions import trim
from pyspark.sql.functions import udf
from pyspark.sql.functions import upper
from pyspark.sql.types import *
from pyspark.sql.types import BooleanType

# from pyspark.sql.functions import to_date
# from pyspark.sql.functions import date_format
# from pyspark.sql.functions import unix_timestamp
# from pyspark.sql.functions import from_unixtime
# from pyspark.sql.functions import from_utc_timestamp
# from pyspark.sql.functions import to_utc_timestamp
# from pyspark.sql.functions import datediff
# from functools import reduce
# from pyjarowinkler.distance import get_jaro_distance
# from pyspark.sql.functions import log2
# from pyspark.sql.functions import log10
# import pyspark.sql.dataframe

__author__ = "Himaprasoon P T, Chandrakanth Nadikuda"


class Transformation:
    """This class provides the api to read files as dataFrames and apply transformations on them"""
    sQLContext = None
    dataFrame = None
    levenshteinDf = None
    levenshteinDfCount = None
    jaroDf = None
    jaroDfCount = None
    df_for_facet = None
    text_facets = OrderedDict()
    num_facets = OrderedDict()
    line_number_column_name = 'DoNotUse_RowNum'
    s3_access_key = None
    s3_secret_key = None

    def __init__(self, sQLContext):
        self.sQLContext = sQLContext

    def set_s3_configuration_parameters(self, access_key, secret_key):
        self.s3_access_key = access_key
        self.s3_secret_key = secret_key
        self.sQLContext._sc._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", access_key)
        self.sQLContext._sc._jsc.hadoopConfiguration().set("fs.s3n.awsSecretAccessKey", secret_key)
        self.sQLContext._sc._jsc.hadoopConfiguration().set("fs.s3.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
        self.sQLContext._sc._jsc.hadoopConfiguration().set("spark.hadoop.fs.s3.impl", "org.apache.hadoop.fs.s3.S3FileSystem");

    def read_from_table(self, table_name, parquet_save_dir_path):
        self.dataFrame = self.sQLContext.read.format("parquet").load(parquet_save_dir_path+"/"+table_name)

    def save_table(self, table_name, parquet_save_dir_path, *fields):
        if len(fields) == 0:
            self.dataFrame.write.format("parquet").save(parquet_save_dir_path+"/"+table_name)
        else:
            self.dataFrame.select(*fields).write.format("parquet").save(parquet_save_dir_path+"/"+table_name)

    # http://stackoverflow.com/questions/31674530/write-single-csv-file-using-spark-csv
    def save_as_csv(self, file_path, *fields):
        if len(fields) == 0:
            self.dataFrame.coalesce(1).write.format("csv").option("header", "true").save(file_path)
        else:
            self.dataFrame.select(*fields).coalesce(1).write.format("csv").option("header", "true").save(file_path)
        if file_path.startswith("s3n"):
            self.save_as_csv_s3(file_path)
            # file_path=file_path.replace("file://", "")
            # destfile=file_path + ".tmp";
            # os.rename(file_path + "/part-00000", destfile)
            # shutil.rmtree(file_path, ignore_errors=True, onerror=None)
            # os.rename(destfile, destfile.replace(".tmp",""))

    def save_as_csv_s3(self, file_path):
        s3 = boto.connect_s3(self.s3_access_key, self.s3_secret_key)
        # Extracting Bucket name
        file_components = file_path.split("/")
        bucket_name = file_components[2]
        # Accessing bucket
        bucket = s3.lookup(bucket_name)
        # Extracting file path components
        file_path_components = file_path.split("//")
        source_file_path = file_path_components[1]
        # Creating destination file path
        dest_file_path = source_file_path.replace(bucket_name + "/", "")
        # Extracting File path of existing file
        source_file_path = dest_file_path + "/part-00000"
        key = bucket.lookup(source_file_path)
        key.copy(bucket_name, dest_file_path + ".temp")
        key.delete()
        key = bucket.lookup(dest_file_path + "/_SUCCESS")
        key.delete()
        key = bucket.lookup(dest_file_path + "_$folder$")
        key.delete()
        key = bucket.lookup(dest_file_path + ".temp")
        key.copy(bucket_name, dest_file_path)
        key.delete()

    def get_schema(self):
        return self.dataFrame.schema

    def read_csv(self, file_path, header):
        self.dataFrame = self.sQLContext.read.format("com.databricks.spark.csv").option("header", header).option("refinementUtil", "true").load(file_path)

    def read_delimited(self, file_path, header, delimiter):
        self.dataFrame = self.sQLContext.read.format("com.databricks.spark.csv").option("delimiter", delimiter).option("header", header).option("refinementUtil", "true").load(file_path)
        self.dataFrame.cache()

    def read_json(self, path):
        self.dataFrame = self.sQLContext.read.json(path)
        self.dataFrame.cache()

    def show(self, limit):
        self.dataFrame.show(limit)

    def asc_sort(self, fields):
        self.dataFrame = self.dataFrame.sort(fields)

    def desc_sort(self, fields):
        self.dataFrame = self.dataFrame.sort(fields, ascending=False)
        self.dataFrame = self.dataFrame.sort(self.dataFrame[fields].desc())

    def to_upper(self, field):
        self.dataFrame = self.dataFrame.withColumn(field, upper(self.dataFrame[field]))

    def to_lower(self, field):
        self.dataFrame = self.dataFrame.withColumn(field, lower(self.dataFrame[field]))

    def trim(self, field):
        self.dataFrame = self.dataFrame.withColumn(field, trim(self.dataFrame[field]))

    def add_id_column(self, field_name):
        self.dataFrame = self.dataFrame.withColumn(field_name, monotonically_increasing_id())

    def split_column_regex(self, field, regex, new_fields):
        self.dataFrame = self.dataFrame.withColumn("brain_temp", split(field, regex))
        for i in new_fields:
            self.dataFrame = self.dataFrame.withColumn(i, self.dataFrame["brain_temp"][new_fields.index(i)])
        self.dataFrame = self.dataFrame.drop("brain_temp")

    def split_column_index(self, field, indices, new_fields):
        zipped_index = list(zip(indices, indices[1:]))

        def splitter(l):
            return [l[k[0]:k[1]] for k in zipped_index]
        ol_val = udf(splitter, ArrayType(StringType()))
        self.dataFrame = self.dataFrame.withColumn("brain_temp", ol_val(field))

        for i in new_fields:
            self.dataFrame = self.dataFrame.withColumn(i, self.dataFrame["brain_temp"][new_fields.index(i)])
        self.dataFrame = self.dataFrame.drop("brain_temp")

    def get_unique(self, *fields):
        if len(fields) == 0:
            return self.dataFrame.select('*').distinct()
        else:
            return self.dataFrame.select(*fields).distinct()

    def remove_duplicates(self, *fields):
        if len(fields) == 0:
            self.dataFrame = self.dataFrame.dropDuplicates()
        else:
            self.dataFrame = self.dataFrame.dropDuplicates(fields)

    def get_max(self, field):
        return (self.dataFrame.agg({field: "max"}).collect()[0])['max('+field+')']

    def get_min(self, field):
        return (self.dataFrame.agg({field: "min"}).collect()[0])['min('+field+')']

    def get_range(self, field):
        return {"min": self.get_min(field), "max": self.get_max(field)}

    def count(self, dataFrame):
        return dataFrame.count()

    def rename_column(self, existing_name, new_name):
        self.dataFrame = self.dataFrame.withColumnRenamed(existing_name, new_name)

    def get_outliers(self, column_name, alpha=3):
        desc_list = self.dataFrame.describe([column_name]).collect()
        stdev = float((desc_list[2])[column_name])
        mean = float((desc_list[1])[column_name])
        return self.dataFrame.filter((self.dataFrame[column_name] < (mean-(alpha*stdev))) | (self.dataFrame[column_name] > (mean+(alpha*stdev))))

    def remove_outliers(self, column_name, alpha=3):
        descList = self.dataFrame.describe([column_name]).collect()
        stdev = float((descList[2])[column_name])
        mean = float((descList[1])[column_name])
        return self.dataFrame.filter((self.dataFrame[column_name] >= (mean-(alpha*stdev))) & (self.dataFrame[column_name] <= (mean+(alpha*stdev))))

    def get_numeric_percentage(self, column_name):
        column_df = self.dataFrame.select(column_name)
        temp_list = column_df.dtypes
        if (temp_list[0])[1] == 'double' or (temp_list[0])[1] == 'int':
            return 100
        else:
            total_count = self.dataFrame.count()
            casted_coln = self.dataFrame[column_name].cast('double')
            castedColnWithoutNull = column_df.withColumn(column_name, casted_coln).na.drop()
            numeric_percentage = ((castedColnWithoutNull.count() * 100)/total_count)
            return numeric_percentage

    def cast_to_numeric_or_remove(self, column_name):
        temp_list = self.dataFrame.select(column_name).dtypes
        if not ((temp_list[0])[1] == 'double' or (temp_list[0])[1] == 'int'):
            castedColn = self.dataFrame[column_name].cast("double")
            self.dataFrame = self.dataFrame.withColumn(column_name, castedColn).na.drop(subset=[column_name])

    def cast_to_numeric(self, column_name, def_val):
        temp_list = self.dataFrame.select(column_name).dtypes
        if not ((temp_list[0])[1] == 'double' or (temp_list[0])[1] == 'int'):
            castedColn = self.dataFrame[column_name].cast("double")
            mymap = {column_name: def_val}
            self.dataFrame = self.dataFrame.withColumn(column_name, castedColn).na.fill(mymap)

    def cast_to_data_type_or_remove(self, column_name,d_type):
        castedColn = self.dataFrame[column_name].cast(d_type)
        self.dataFrame = self.dataFrame.withColumn(column_name, castedColn).na.drop(subset=[column_name])

    def get_frequency(self, column_name):
        return self.dataFrame.groupBy(column_name).count()

    def get_records_with_column_frequency_less_than_limit(self, column_name, limit):
        g = self.dataFrame.groupBy(column_name).count()
        gf = g.filter("count<"+str(limit)).select(column_name).map(lambda x: x[column_name]).collect()
        self.dataFrame = self.dataFrame.filter(self.dataFrame[column_name].isin(gf))

    def get_records_with_column_frequency_greater_than_limit(self, column_name, limit):
        g = self.dataFrame.groupBy(column_name).count()
        gf = g.filter("count>"+str(limit)).select(column_name).map(lambda x: x[column_name]).collect()
        self.dataFrame = self.dataFrame.filter(self.dataFrame[column_name].isin(gf))

    def filter(self, condition):
        self.dataFrame = self.dataFrame.filter(condition)

    def filter_custom(self, column, value, is_regex, page_size):
        if (is_regex is False):
            self.filter_text(column, value, page_size)
        else:
            self.filter_by_regex(column, value, page_size)

    def filter_text(self, column, value, page_size):
        equal = '='
        quotes = '"'
        condition = column + equal + quotes + value + quotes
        res = self.dataFrame.filter(condition)
        self.display(res, page_size)

    def filter_by_regex(self, column, regex, page_size):
        def filter_fn(s):
            return re.search(regex, s) is not None

        filter_udf = F.udf(filter_fn, BooleanType())
        res = self.dataFrame.filter(filter_udf(self.dataFrame[column]))
        self.display(res, page_size)

    def display(self, dataFrame, page_size):
        dataFrame = dataFrame.limit(page_size)
        page_res = {}
        page_res['df_as_json'] = self.get_df_as_dict(dataFrame)
        page_res['start_line'] = 0
        page_res['end_line'] = self.count(dataFrame)
        page_res['total_lines'] = self.count(dataFrame)
        page_res['data_types'] = dict(dataFrame.dtypes)
        dataFrame = self.remove_column_dataFrame(dataFrame, self.line_number_column_name)
        print(json.dumps(page_res))



    def select(self, *fields):
        self.dataFrame = self.dataFrame.select(*fields)

    def copy_column(self, column_name, new_column_name):
        self.dataFrame = self.dataFrame.withColumn(new_column_name, self.dataFrame[column_name])

    def regex_replace_on_column(self, column_name, regex, replacement, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, regexp_replace(self.dataFrame[column_name], regex, replacement))

    def multiply_val(self, column_name, value, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, self.dataFrame[column_name] * value)

    def divide_val(self, column_name, value, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, self.dataFrame[column_name] / value)

    def add_val(self, column_name, value, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, self.dataFrame[column_name] + value)

    def sub_val(self, column_name, value, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, self.dataFrame[column_name] - value)

    def add(self, field1, field2, new_column_name=None):
        if not new_column_name:
            new_column = field1
        else:
            new_column = new_column_name
        temp = self.dataFrame[field1] + self.dataFrame[field2]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def sub(self, field1, field2, new_column_name=None):
        if not new_column_name:
            new_column = field1
        else:
            new_column = new_column_name
        temp = self.dataFrame[field1] - self.dataFrame[field2]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def multiply(self, field1, field2, new_column_name=None):
        if not new_column_name:
            new_column = field1
        else:
            new_column = new_column_name
        temp = self.dataFrame[field1] * self.dataFrame[field2]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def divide(self, field1, field2, new_column_name=None):
        if not new_column_name:
            new_column = field1
        else:
            new_column = new_column_name
        temp = self.dataFrame[field1] / self.dataFrame[field2]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def add_all(self, field_names_list, new_column_name=None):
        if len(field_names_list) != 0:
            if not new_column_name:
                new_column = field_names_list[0]
            else:
                new_column = new_column_name
            temp = None
            for field in field_names_list:
                if temp:
                    temp += self.dataFrame[field]
                else:
                    temp = self.dataFrame[field]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def sub_all(self, field_names_list, new_column_name=None):
        if len(field_names_list) != 0:
            if not new_column_name:
                new_column = field_names_list[0]
            else:
                new_column = new_column_name
            temp=None
            for field in field_names_list:
                if temp:
                    temp -= self.dataFrame[field]
                else:
                    temp = self.dataFrame[field]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def multiply_all(self, field_names_list, new_column_name=None):
        if len(field_names_list) != 0:
            if not new_column_name:
                new_column = field_names_list[0]
            else:
                new_column = new_column_name
            temp=None
            for field in field_names_list:
                if temp:
                    temp *= self.dataFrame[field]
                else:
                    temp = self.dataFrame[field]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def divide_all(self, field_names_list, new_column_name=None):
        if len(field_names_list) != 0:
            if not new_column_name:
                new_column = field_names_list[0]
            else:
                new_column = new_column_name
            temp = None
            for field in field_names_list:
                if temp:
                    temp /= self.dataFrame[field]
                else:
                    temp = self.dataFrame[field]
        self.dataFrame = self.dataFrame.withColumn(new_column, temp)

    def root(self, column_name, n, new_column_name=None):
        exponent = 1.0/n
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, pow(self.dataFrame[column_name], exponent))

    def power(self, column_name, exponent, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, pow(self.dataFrame[column_name], exponent))

    def loge(self, column_name, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, log(self.dataFrame[column_name]))

    def log(self, column_name, base, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, log(base, self.dataFrame[column_name]))

    def log10(self, column_name, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, log10(self.dataFrame[column_name]))

    def log2(self, column_name, new_column_name=None):
        if not new_column_name:
            new_column = column_name
        else:
            new_column = new_column_name
        self.dataFrame = self.dataFrame.withColumn(new_column, log2(self.dataFrame[column_name]))

    def sub_string(self, field, start_pos, end_pos,  new_column=None):
        if not new_column:
            new_column = field
        self.dataFrame = self.dataFrame.withColumn(new_column, self.dataFrame[field].substr(start_pos, end_pos))

    def from_unix_time(self, field, time_format='yyyy-MM-dd HH:mm:ss', new_column=None):
        if not new_column:
            new_column = field
        self.dataFrame = self.dataFrame.withColumn(new_column,
                                                   to_date(from_unixtime(self.dataFrame[field], time_format)))

    def format_date(self, field, time_format='yyyy-MM-dd HH:mm:ss', new_column=None):
        if not new_column:
            new_column = field
        self.dataFrame = self.dataFrame.withColumn(new_column, date_format(self.dataFrame[field], time_format))

    def get_month(self, field, new_column=None):
        self.format_date(field, "MMM", new_column)

    def get_day(self, field, new_column=None):
        self.format_date(field, "EEE", new_column)

    def get_year(self, field, new_column=None):
        self.format_date(field, "yyyy", new_column)

    def to_unix_time_stamp(self, field, time_format='yyyy-MM-dd', new_column=None):
        if not new_column:
            new_column = field
        self.dataFrame = self.dataFrame.withColumn(new_column, unix_timestamp(self.dataFrame[field], time_format))

    def change_timezone(self, field, from_zone, to_zone, new_column=None):
        if not new_column:
            new_column = field
        self.dataFrame = self.dataFrame.withColumn(new_column, from_utc_timestamp(to_utc_timestamp(
            self.dataFrame[field], from_zone), to_zone))

    def dates_between(self, field1, field2, new_column=None):
        if not new_column:
            new_column = field1
        self.dataFrame = self.dataFrame.withColumn(new_column, datediff(self.dataFrame[field1], self.dataFrame[field2]))

    def join(self, other, on=None, how=None):
        if isinstance(other, Transformation):
            self.dataFrame = self.dataFrame.join(other.dataFrame, on, how)
        elif isinstance(other,  pyspark.sql.DataFrame):
            self.dataFrame = self.dataFrame.join(other, on, how)

    def cartesian_join(self, other):
        self.join(other)

    def join_based_on(self, other, column_pairs, how=None):
        def do():
            k = reduce((lambda s, t: s & t), map((lambda x: self.dataFrame[x[0]] == other[x[1]]), column_pairs))
            self.dataFrame = self.dataFrame.join(other, on=k, how=how)
        if isinstance(other, Transformation):
            other = other.dataFrame
            do()
        elif isinstance(other,  pyspark.sql.DataFrame):
            do()

    def equi_join(self, other, column_list):
        if isinstance(other, Transformation):
            self.dataFrame = self.dataFrame.join(other.dataFrame, on=column_list, )
        elif isinstance(other,  pyspark.sql.DataFrame):
            self.dataFrame = self.dataFrame.join(other, on=column_list)

    def cluster_levenshtein(self, field):
        def minimum(a, b):
            if a <= b:
                return a
            else:
                return b
        def levenshtein(s1, s2):
            if len(s1) > len(s2):
                s1, s2 = s2, s1
            distances = range(len(s1) + 1)
            for index2, char2 in enumerate(s2):
                newdistances = [index2+1]
                for index1, char1 in enumerate(s1):
                    if char1 == char2:
                        newdistances.append(distances[index1])
                    else:
                        newdistances.append(1 + minimum(minimum(distances[index1],
                                                                distances[index1+1]), newdistances[-1]))
                distances = newdistances
            return distances[-1]
        leven = udf(levenshtein, StringType())
        self.levenshteinDf = self.dataFrame.select(col(field)).dropDuplicates()
        self.levenshteinDf = self.levenshteinDf.join(self.levenshteinDf.withColumnRenamed(field, "tempField")
                                                     ).filter("tempField!="+field)
        self.levenshteinDf = self.levenshteinDf.filter(leven(self.levenshteinDf[field], self.levenshteinDf["tempField"])
                                                       .cast(DoubleType()) < 3)
        self.levenshteinDfCount = self.levenshteinDf.groupBy(field).count()

    def cluster_jaro_winkler(self, field):
        def jaroDist(s1, s2):
            return get_jaro_distance(s1, s2, winkler=True, scaling=0.1)
        jaro = udf(jaroDist, StringType())
        self.jaroDf = self.dataFrame.select(col(field)).dropDuplicates()
        self.jaroDf = self.jaroDf.join(self.jaroDf.withColumnRenamed(field, "tempField")
                                       ).filter("tempField!=" + field)
        self.jaroDf = self.jaroDf.filter(jaro(self.jaroDf[field], self.jaroDf["tempField"])
                                         > 0.78)
        self.jaroDfCount = self.jaroDf.groupBy(field).count()

    def new_text_facet(self, field):
        if self.df_for_facet is None:
            self.df_for_facet = self.dataFrame
        k = self.df_for_facet.groupBy(field).count()
        self.text_facets[field] = Facet("text")
        return self.get_df_as_dict(k)

    def create_unique_vector(self,field):
        unique_list=self.dataFrame.select(field).distinct().flatMap(list).collect()
        for unique_values in unique_list:
            self.create_vector_column(field,unique_values,unique_values)


    def create_vector_column(self,old_column,compare,new_col_name):
        def valueToCategory(value):
            if   value == compare:
                return 1
            else :
                return 0
        udfValueToCategory = udf(valueToCategory, IntegerType())
        self.dataFrame = self.dataFrame.withColumn(old_column+"."+new_col_name, udfValueToCategory(old_column))
        



    def edit_text_facet(self, field, old_val, new_val=None):
        self.text_facets[field].edit(old_val, new_val)

        def change_val(col):
            if col == old_val:
                return new_val
            else:
                return col
        change = udf(change_val, StringType())
        txt_facet_list = []
        num_facet_list = []
        if new_val is None: # removing
            self.df_for_facet = self.df_for_facet.filter(self.df_for_facet[field] != old_val)
        else:# edit
            self.df_for_facet = self.df_for_facet.withColumn(field, change(field))
        for key, value in self.text_facets.items():
            txt_facet_list.append(self.get_df_as_dict(self.df_for_facet.groupBy(key).count()))
        for key, value in self.num_facets.items():
            self.df_for_facet = self.df_for_facet.filter(col(key).between(value.min, value.max))
        for key, value in self.num_facets.items():
            num_facet_list.append(self.get_df_as_dict(self.df_for_facet.groupBy(key).count()))
        return {"txt_facet_list":txt_facet_list , "num_facet_list" : num_facet_list  }

    def new_num_facet(self, field):
        if self.df_for_facet is None:
            self.df_for_facet = self.dataFrame
        max_val = self.df_for_facet.groupBy().max(field).first()[0]
        min_val = self.df_for_facet.groupBy().min(field).first()[0]
        self.num_facets[field] = Facet("text", min_val, max_val)
        return self.get_df_as_dict(self.df_for_facet.groupBy(field).count())

    def modify_num_facet(self, field, new_min, new_max):
        facet = self.num_facets[field]
        num_facet_list = []
        txt_facet_list = []
        if new_max > facet.max or new_min < facet.min:
            self.df_for_facet = self.dataFrame
            facet.modify_num(new_min,new_max)
            for key, value in self.num_facets.items():
                print("key" +key)
                print((value.min, value.max))
                self.df_for_facet = self.df_for_facet.filter(col(key).between(value.min, value.max))
                #num_facet_list.append(self.get_df_as_dict(self.df_for_facet.groupBy(key).count()))
        else:
            facet.modify_num(new_min,new_max)
            for key, value in self.num_facets.items():
                self.df_for_facet = self.df_for_facet.filter(col(key).between(value.min, value.max))
        for key, value in self.text_facets.items():
            if value.modified and key != field:
                for i in value.txt_edits:
                    if i[1] is None:
                        self.df_for_facet = self.df_for_facet.filter(self.df_for_facet[key] != i[0])
                    else:
                        def change_val2(col):
                            if col == i[0]:
                                return i[1]
                            else:
                                return col
                        change2 = udf(change_val2,StringType())
                        self.df_for_facet = self.df_for_facet.withColumn(key, change2(key))
        for key, value in self.num_facets.items():
            num_facet_list.append(self.get_df_as_dict(self.df_for_facet.groupBy(key).count()))
        for key, value in self.text_facets.items():
            txt_facet_list.append(self.get_df_as_dict(self.df_for_facet.groupBy(key).count()))
        return  {"txt_facet_list":txt_facet_list , "num_facet_list" : num_facet_list  }

    def get_df_as_dict(self, df, num=None):
        g = None
        if num is None:
            g = df
        else:
            g = df.limit(num)
        df_map = OrderedDict()
        for i in g.columns:
            df_map[i] = g.select(i).map(lambda x: x[0]).collect()
        return df_map

    def order_facet(self, field , by_name=False, by_count=False):
        ft = self.text_facets.get(field, self.num_facets.get(field))
        if ft is not None:
            if by_name:
                return self.get_df_as_dict(self.df_for_facet.groupBy(field).count().sort(field))
            elif by_count:
                return self.get_df_as_dict(self.df_for_facet.groupBy(field).count().sort("count"))

    def add_row_number(self, dataFrame):
        row_with_index = Row(*[self.line_number_column_name] + dataFrame.columns)
        def make_row(columns):
            def _make_row(row, uid):
                row_dict = row.asDict()
                return row_with_index(*[uid] + [row_dict.get(c) for c in columns])
            return _make_row

        f = make_row(dataFrame.columns)

        dataFrame = (dataFrame.rdd
                     .zipWithIndex()
                     .map(lambda x: f(*x))
                     .toDF(
            StructType([StructField(self.line_number_column_name, LongType(), False)] + self.dataFrame.schema.fields)))
        return dataFrame

    def paginate(self, start, end):
        self.dataFrame = self.remove_column_dataFrame(self.dataFrame, self.line_number_column_name)
        self.dataFrame = self.add_row_number(self.dataFrame)
        page_res = {}
        page_res['df_as_json'] = self.get_df_as_dict(self.dataFrame.filter(col(self.line_number_column_name).between(start-1,end-1)))
        page_res['start_line'] = start
        page_res['end_line'] = end
        page_res['total_lines'] = self.count(self.dataFrame)
        page_res['data_types'] = dict(self.dataFrame.dtypes)
        print(json.dumps(page_res))


    def paginate_and_write_result(self, start, end, result_file_path):
        self.dataFrame = self.remove_column_dataFrame(self.dataFrame, self.line_number_column_name)
        self.dataFrame = self.add_row_number(self.dataFrame)
        page_res = {}
        page_res['df_as_json'] = self.get_df_as_dict(self.dataFrame.filter(col(self.line_number_column_name).between(start-1,end-1)))
        page_res['start_line'] = start
        page_res['end_line'] = end
        page_res['total_lines'] = self.count(self.dataFrame)
        page_res['data_types'] = dict(self.dataFrame.dtypes)
        # Writing to file
        text_file = open(result_file_path, "w")
        text_file.write(json.dumps(page_res))
        text_file.close()

    def apply_facets(self):
        self.dataFrame = self.df_for_facet
        self.df_for_facet = None;
        self.text_facets.clear()
        self.num_facets.clear()

    def remove_column(self, *fields):
        for field in fields:
            self.dataFrame = self.dataFrame.drop(field)
        return self.dataFrame

    def remove_column_dataFrame(self, dataFrame,*fields):
        for field in fields:
            dataFrame = dataFrame.drop(field)
        return dataFrame

    def to_titlecase(self, field):
        self.dataFrame = self.dataFrame.withColumn(field, initcap(self.dataFrame[field]))

    def unpersist(self):
        self.dataFrame.clearCache()
        self.dataFrame.unpersist()

class Facet:

    facet_type = None
    modified = False
    txt_edits = []
    init_max = None
    init_min = None
    min = None
    max = None
    order = None

    def __init__(self, facet_type, min_val=None, max_val=None):
        self.facet_type = facet_type
        self.init_max = max_val
        self.init_min = min_val
        self.max = max_val
        self.min = min_val

    def edit(self, old_val, new_val=None):
        self.txt_edits.append([old_val, new_val])
        self.modified = True

    def modify_num(self, min_val, max_val):
        self.max = max_val
        self.min = min_val
        self.modified = True


